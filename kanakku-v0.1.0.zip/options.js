// src/shared/settings.ts
var SETTINGS_STORAGE_KEY = "kanakku_settings";
var DEFAULT_SETTINGS = {
  billingProjectId: "",
  datasetName: "",
  summaryTableName: "",
  cacheMinutes: 60,
  monthlyAlertThreshold: 0,
  aiExplanationsEnabled: false,
  geminiApiKey: ""
};
function normalizeSettings(raw) {
  const cacheMinutes = typeof raw?.cacheMinutes === "number" && Number.isFinite(raw.cacheMinutes) && raw.cacheMinutes > 0 ? Math.round(raw.cacheMinutes) : DEFAULT_SETTINGS.cacheMinutes;
  const monthlyAlertThreshold = typeof raw?.monthlyAlertThreshold === "number" && Number.isFinite(raw.monthlyAlertThreshold) && raw.monthlyAlertThreshold > 0 ? Math.round(raw.monthlyAlertThreshold * 100) / 100 : DEFAULT_SETTINGS.monthlyAlertThreshold;
  return {
    billingProjectId: (raw?.billingProjectId ?? "").trim(),
    datasetName: (raw?.datasetName ?? "").trim(),
    summaryTableName: (raw?.summaryTableName ?? "").trim(),
    cacheMinutes,
    monthlyAlertThreshold,
    aiExplanationsEnabled: Boolean(raw?.aiExplanationsEnabled),
    geminiApiKey: (raw?.geminiApiKey ?? "").trim()
  };
}
async function loadSettings() {
  const stored = await chrome.storage.local.get(SETTINGS_STORAGE_KEY);
  return normalizeSettings(
    stored[SETTINGS_STORAGE_KEY]
  );
}
async function saveSettings(settings) {
  const normalized = normalizeSettings(settings);
  await chrome.storage.local.set({ [SETTINGS_STORAGE_KEY]: normalized });
  return normalized;
}

// src/options/options.ts
function getElement(id) {
  const el = document.getElementById(id);
  if (!el) {
    throw new Error(`Missing expected element: #${id}`);
  }
  return el;
}
function readFormSettings() {
  const projectInput = getElement("billing-project-id");
  const datasetInput = getElement("dataset-name");
  const tableInput = getElement("summary-table-name");
  const cacheInput = getElement("cache-minutes");
  const alertInput = getElement("monthly-alert-threshold");
  const aiInput = getElement("ai-explanations");
  const geminiInput = getElement("gemini-api-key");
  return {
    billingProjectId: projectInput.value,
    datasetName: datasetInput.value,
    summaryTableName: tableInput.value,
    cacheMinutes: Number(cacheInput.value),
    monthlyAlertThreshold: Number(alertInput.value),
    aiExplanationsEnabled: aiInput.checked,
    geminiApiKey: geminiInput.value
  };
}
function writeFormSettings(settings) {
  getElement("billing-project-id").value = settings.billingProjectId;
  getElement("dataset-name").value = settings.datasetName;
  getElement("summary-table-name").value = settings.summaryTableName;
  getElement("cache-minutes").value = String(
    settings.cacheMinutes
  );
  getElement("monthly-alert-threshold").value = String(
    settings.monthlyAlertThreshold
  );
  getElement("ai-explanations").checked = settings.aiExplanationsEnabled;
  getElement("gemini-api-key").value = settings.geminiApiKey;
}
function showStatusBanner(ok, message) {
  const banner = getElement("connection-status");
  banner.textContent = message;
  banner.classList.remove("hidden", "ok", "error");
  banner.classList.add(ok ? "ok" : "error");
}
function updateAuthStatus(status) {
  const label = getElement("auth-status");
  label.textContent = status.message;
}
async function initOptionsPage() {
  const settings = await loadSettings();
  writeFormSettings(settings);
  const authStatus = await chrome.runtime.sendMessage({ type: "GET_AUTH_STATUS" });
  updateAuthStatus(authStatus);
  getElement("sign-in-btn").addEventListener("click", () => {
    void (async () => {
      const result = await chrome.runtime.sendMessage({ type: "SIGN_IN" });
      updateAuthStatus(result);
    })();
  });
  getElement("settings-form").addEventListener(
    "submit",
    (event) => {
      event.preventDefault();
      void (async () => {
        const saved = await saveSettings(readFormSettings());
        writeFormSettings(saved);
        showStatusBanner(true, "Settings saved.");
      })();
    }
  );
  getElement("test-btn").addEventListener("click", () => {
    const testBtn = getElement("test-btn");
    testBtn.disabled = true;
    showStatusBanner(true, "Testing BigQuery connection\u2026");
    void chrome.runtime.sendMessage({
      type: "TEST_CONNECTION",
      settings: readFormSettings()
    }).then((result) => showStatusBanner(result.ok, result.message)).catch(
      () => showStatusBanner(
        false,
        "Could not test the connection. Please try again."
      )
    ).finally(() => {
      testBtn.disabled = false;
    });
  });
  getElement("clear-btn").addEventListener("click", () => {
    void (async () => {
      const result = await chrome.runtime.sendMessage({ type: "CLEAR_ALL_DATA" });
      writeFormSettings(DEFAULT_SETTINGS);
      updateAuthStatus({ signedIn: false, message: "Not signed in." });
      showStatusBanner(result.ok, result.message);
    })();
  });
}
if (typeof document !== "undefined") {
  void initOptionsPage();
}
export {
  initOptionsPage
};
