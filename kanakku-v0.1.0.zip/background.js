// src/core/format/index.ts
function formatMoney(amount, currency) {
  const code = currency || "USD";
  try {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: code,
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(amount);
  } catch {
    return `${code} ${amount.toFixed(2)}`;
  }
}

// src/core/ai/index.ts
var GEMINI_ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent";
function buildStandardExecutiveSummary(input) {
  const parts = [
    `${input.title} in ${input.projectId}: final spend this month is ${formatMoney(input.finalPrice, input.currency)} (list ${formatMoney(input.listPrice, input.currency)}).`
  ];
  const cudAbs = Math.abs(input.cudCredits);
  if (cudAbs > 5e-3 || input.totalSavings > 5e-3) {
    parts.push(
      `Savings total ${formatMoney(input.totalSavings, input.currency)} (including ${formatMoney(cudAbs, input.currency)} from CUDs).`
    );
  }
  if (input.percentChange !== null && Number.isFinite(input.percentChange)) {
    const rounded = Math.round(input.percentChange);
    const dir = rounded >= 0 ? `+${rounded}%` : `${rounded}%`;
    parts.push(`Spend is ${dir} vs. the same days last month.`);
  }
  const topAction = input.insights.find((item) => item.action)?.action;
  if (topAction) {
    parts.push(`Recommended action: ${topAction}`);
  } else {
    parts.push("No immediate cost anomalies detected.");
  }
  return {
    source: "standard",
    text: parts.join(" ")
  };
}
async function generateExecutiveSummary(input, aiConfig, fetchFn = fetch) {
  const standard = buildStandardExecutiveSummary(input);
  const apiKey = aiConfig.apiKey.trim();
  if (!aiConfig.enabled || !apiKey) {
    return standard;
  }
  const prompt = [
    "You are a concise FinOps & SRE advisor. Give a 2-sentence executive summary and 1 concrete action item from this visible cost summary only:",
    `Target: ${input.title} (project ${input.projectId})`,
    `Final price MTD: ${formatMoney(input.finalPrice, input.currency)}`,
    `List price MTD: ${formatMoney(input.listPrice, input.currency)}`,
    `CUD credits MTD: ${formatMoney(Math.abs(input.cudCredits), input.currency)}`,
    `Total savings MTD: ${formatMoney(input.totalSavings, input.currency)}`,
    `Insights: ${input.insights.map((i) => `${i.title}: ${i.action ?? i.detail}`).join(" | ") || "None"}`
  ].join("\n");
  try {
    const response = await fetchFn(GEMINI_ENDPOINT, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-goog-api-key": apiKey
      },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }]
      })
    });
    if (!response.ok) {
      const reason = response.status === 400 ? "invalid API key" : response.status === 403 ? "API key restricted or Generative Language API disabled" : response.status === 429 ? "quota exceeded" : `HTTP ${response.status}`;
      return {
        ...standard,
        note: `Gemini request failed (${reason}) \u2014 showing standard summary.`
      };
    }
    const json = await response.json();
    const text = json.candidates?.[0]?.content?.parts?.[0]?.text?.trim();
    if (!text) {
      return {
        ...standard,
        note: "Empty Gemini response \u2014 showing standard summary."
      };
    }
    return { source: "gemini", text };
  } catch {
    return {
      ...standard,
      note: "Could not reach Gemini \u2014 showing standard summary."
    };
  }
}

// src/core/billing/cache.ts
var CACHE_PREFIX = "kanakku_cost_cache_v2:";
var LIST_CACHE_PREFIX = "kanakku_list_cache_v2:";
var PROJECT_CACHE_PREFIX = "kanakku_project_cache_v2:";
function buildCacheKey(resource) {
  return [
    CACHE_PREFIX,
    resource.projectId,
    resource.serviceType,
    resource.regionOrZone ?? "_",
    resource.resourceName
  ].join(":");
}
function buildListCacheKey(list) {
  return [LIST_CACHE_PREFIX, list.projectId, list.serviceType].join(":");
}
function buildProjectCacheKey(projectId) {
  return `${PROJECT_CACHE_PREFIX}:${projectId}`;
}
function getDefaultStorage() {
  return chrome.storage.local;
}
async function getCachedValue(key, nowMs = Date.now(), storage = getDefaultStorage()) {
  const result = await storage.get(key);
  const entry = result[key];
  if (!entry || entry.expiresAt <= nowMs) {
    return null;
  }
  return {
    ...entry.value,
    fromCache: true
  };
}
async function setCachedValue(key, value, cacheMinutes, nowMs = Date.now(), storage = getDefaultStorage()) {
  const ttlMs = Math.max(1, cacheMinutes) * 6e4;
  const entry = {
    expiresAt: nowMs + ttlMs,
    value: { ...value, fromCache: false }
  };
  await storage.set({ [key]: entry });
}
var getCachedSummary = getCachedValue;
var setCachedSummary = setCachedValue;
var getCachedBreakdown = getCachedValue;
var setCachedBreakdown = setCachedValue;

// src/core/billing/connection.ts
var PROJECT_ID_PATTERN = /^[a-z0-9][a-z0-9-]{4,28}[a-z0-9]$/;
var BIGQUERY_IDENTIFIER_PATTERN = /^[a-zA-Z0-9_]{1,1024}$/;
function validateBigQueryTarget(target) {
  const project = target.billingProjectId.trim();
  const dataset = target.datasetName.trim();
  const table = target.summaryTableName.trim();
  if (!project) {
    return { ok: false, message: "Enter your billing project ID first." };
  }
  if (!PROJECT_ID_PATTERN.test(project)) {
    return {
      ok: false,
      message: "Billing project ID looks invalid. Use lowercase letters, numbers, and hyphens."
    };
  }
  if (!dataset || !BIGQUERY_IDENTIFIER_PATTERN.test(dataset)) {
    return {
      ok: false,
      message: "Dataset name must contain only letters, numbers, and underscores."
    };
  }
  if (!table || !BIGQUERY_IDENTIFIER_PATTERN.test(table)) {
    return {
      ok: false,
      message: "Summary table name must contain only letters, numbers, and underscores."
    };
  }
  return { ok: true };
}
function buildTestQuery(target) {
  const project = target.billingProjectId.trim();
  const dataset = target.datasetName.trim();
  const table = target.summaryTableName.trim();
  return `SELECT 1 FROM \`${project}.${dataset}.${table}\` LIMIT 1`;
}
function mapHttpErrorToMessage(status) {
  if (status === 401) {
    return "Google sign-in expired or was cancelled. Please sign in again.";
  }
  if (status === 403) {
    return "Access denied. Check that your account has BigQuery Data Viewer and BigQuery Job User access on this project.";
  }
  if (status === 404) {
    return "Billing summary table not found. Check your project ID, dataset name, and table name, or open the setup guide.";
  }
  if (status === 400) {
    return "BigQuery rejected the query. Check your project ID, dataset name, and table name.";
  }
  return `BigQuery returned an unexpected error (HTTP ${status}). Please try again.`;
}
async function testBigQueryConnection(target, accessToken, fetchFn = fetch) {
  const validation = validateBigQueryTarget(target);
  if (!validation.ok) {
    return validation;
  }
  const projectId = target.billingProjectId.trim();
  const endpoint = `https://bigquery.googleapis.com/bigquery/v2/projects/${encodeURIComponent(projectId)}/queries`;
  try {
    const response = await fetchFn(endpoint, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        query: buildTestQuery(target),
        useLegacySql: false,
        maxResults: 1,
        timeoutMs: 1e4
      })
    });
    if (!response.ok) {
      return {
        ok: false,
        message: mapHttpErrorToMessage(response.status)
      };
    }
    return {
      ok: true,
      message: "Connected! Found the summary table in BigQuery."
    };
  } catch {
    return {
      ok: false,
      message: "Could not reach BigQuery. Check your internet connection and try again."
    };
  }
}

// src/core/billing/math.ts
function formatUtcDate(date) {
  const year = date.getUTCFullYear();
  const month = String(date.getUTCMonth() + 1).padStart(2, "0");
  const day = String(date.getUTCDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}
function getPriorMonthRange(referenceDate) {
  const year = referenceDate.getUTCFullYear();
  const month = referenceDate.getUTCMonth();
  const day = referenceDate.getUTCDate();
  const priorMonthStart = new Date(Date.UTC(year, month - 1, 1));
  const priorMonthLastDay = new Date(Date.UTC(year, month, 0)).getUTCDate();
  const clampedDay = Math.min(day, priorMonthLastDay);
  const priorMonthEnd = new Date(Date.UTC(year, month - 1, clampedDay));
  return {
    start: formatUtcDate(priorMonthStart),
    end: formatUtcDate(priorMonthEnd)
  };
}
function buildThirtyDaySeries(byDate, referenceDate) {
  const series = [];
  const baseUtc = Date.UTC(
    referenceDate.getUTCFullYear(),
    referenceDate.getUTCMonth(),
    referenceDate.getUTCDate()
  );
  for (let offset = 29; offset >= 0; offset--) {
    const dayDate = new Date(baseUtc - offset * 864e5);
    const key = formatUtcDate(dayDate);
    const entry = byDate.get(key);
    series.push({
      date: key,
      costAfterCredits: entry?.after ?? 0,
      costBeforeDiscounts: entry?.before ?? 0
    });
  }
  return series;
}
function summarizeBillingRows(rows, precision, referenceDate = /* @__PURE__ */ new Date(), fetchedAt = Date.now()) {
  const thisMonthStart = formatUtcDate(
    new Date(
      Date.UTC(referenceDate.getUTCFullYear(), referenceDate.getUTCMonth(), 1)
    )
  );
  const today = formatUtcDate(referenceDate);
  const priorRange = getPriorMonthRange(referenceDate);
  let thisMonthListPrice = 0;
  let thisMonthBeforeDiscounts = 0;
  let thisMonthCudCredits = 0;
  let thisMonthOtherCredits = 0;
  let thisMonthAfterCredits = 0;
  let lastMonthSameDaysAfterCredits = 0;
  let latestUsageTime = null;
  let currency = "USD";
  const byDate = /* @__PURE__ */ new Map();
  for (const row of rows) {
    if (row.currency) {
      currency = row.currency;
    }
    const existing = byDate.get(row.usageDate);
    byDate.set(row.usageDate, {
      after: (existing?.after ?? 0) + row.costAfterCredits,
      before: (existing?.before ?? 0) + row.costBeforeDiscounts
    });
    if (row.usageDate >= thisMonthStart && row.usageDate <= today) {
      const effectiveList = row.costAtList > 0 ? row.costAtList : row.costBeforeDiscounts;
      thisMonthListPrice += effectiveList;
      thisMonthBeforeDiscounts += row.costBeforeDiscounts;
      thisMonthCudCredits += row.cudCredits;
      thisMonthOtherCredits += row.otherCredits;
      thisMonthAfterCredits += row.costAfterCredits;
    }
    if (row.usageDate >= priorRange.start && row.usageDate <= priorRange.end) {
      lastMonthSameDaysAfterCredits += row.costAfterCredits;
    }
    if (row.latestUsageTime && (!latestUsageTime || row.latestUsageTime > latestUsageTime)) {
      latestUsageTime = row.latestUsageTime;
    }
  }
  const thisMonthContractDiscount = Math.max(
    0,
    thisMonthListPrice - thisMonthBeforeDiscounts
  );
  const totalSavings = Math.max(0, thisMonthListPrice - thisMonthAfterCredits);
  const savingsPercent = thisMonthListPrice > 0 ? totalSavings / thisMonthListPrice * 100 : null;
  const percentChange = lastMonthSameDaysAfterCredits > 0 ? (thisMonthAfterCredits - lastMonthSameDaysAfterCredits) / lastMonthSameDaysAfterCredits * 100 : null;
  return {
    currency,
    thisMonthListPrice,
    thisMonthContractDiscount,
    thisMonthBeforeDiscounts,
    thisMonthCudCredits,
    thisMonthOtherCredits,
    thisMonthAfterCredits,
    totalSavings,
    savingsPercent,
    lastMonthSameDaysAfterCredits,
    percentChange,
    dailySeries: buildThirtyDaySeries(byDate, referenceDate),
    latestUsageTime,
    precision,
    fetchedAt,
    fromCache: false
  };
}

// src/core/billing/query.ts
var SERVICE_DESCRIPTION_MAP = {
  "cloud-run": "Cloud Run",
  "compute-engine": "Compute Engine",
  "cloud-storage": "Cloud Storage",
  gke: "Kubernetes Engine",
  bigquery: "BigQuery",
  "vertex-ai": "Vertex AI",
  "cloud-sql": "Cloud SQL",
  pubsub: "Cloud Pub/Sub",
  "artifact-registry": "Artifact Registry"
};
function buildResourceCostQuery(target, resourceLevel) {
  const project = target.billingProjectId.trim();
  const dataset = target.datasetName.trim();
  const table = target.summaryTableName.trim();
  const resourceFilter = resourceLevel ? `
    AND (
      resource_name = @resourceName
      OR resource_global_name = @resourceName
      OR ENDS_WITH(resource_global_name, CONCAT('/', @resourceName))
    )` : "";
  return `SELECT
  FORMAT_DATE('%Y-%m-%d', usage_date) AS usage_date,
  ANY_VALUE(currency) AS currency,
  SUM(CAST(IFNULL(cost_at_list, 0) AS FLOAT64)) AS cost_at_list,
  SUM(CAST(cost_before_discounts AS FLOAT64)) AS cost_before_discounts,
  SUM(CAST(IFNULL(cud_credits, 0) AS FLOAT64)) AS cud_credits,
  SUM(CAST(IFNULL(other_credits, 0) AS FLOAT64)) AS other_credits,
  SUM(CAST(cost_after_credits AS FLOAT64)) AS cost_after_credits,
  FORMAT_TIMESTAMP('%Y-%m-%dT%H:%M:%SZ', MAX(latest_usage_time)) AS latest_usage_time
FROM \`${project}.${dataset}.${table}\`
WHERE usage_date >= DATE_SUB(DATE_TRUNC(CURRENT_DATE(), MONTH), INTERVAL 1 MONTH)
  AND project_id = @projectId
  AND service_description = @serviceDescription${resourceFilter}
GROUP BY usage_date
ORDER BY usage_date ASC`;
}
function buildQueryParameters(resource, resourceLevel) {
  const params = [
    {
      name: "projectId",
      parameterType: { type: "STRING" },
      parameterValue: { value: resource.projectId }
    },
    {
      name: "serviceDescription",
      parameterType: { type: "STRING" },
      parameterValue: { value: SERVICE_DESCRIPTION_MAP[resource.serviceType] }
    }
  ];
  if (resourceLevel) {
    params.push({
      name: "resourceName",
      parameterType: { type: "STRING" },
      parameterValue: { value: resource.resourceName }
    });
  }
  return params;
}
function buildServiceBreakdownQuery(target) {
  const project = target.billingProjectId.trim();
  const dataset = target.datasetName.trim();
  const table = target.summaryTableName.trim();
  return `SELECT
  COALESCE(NULLIF(resource_name, ''), NULLIF(resource_global_name, ''), '(project-level)') AS resource_label,
  ANY_VALUE(currency) AS currency,
  SUM(CAST(IFNULL(cost_at_list, 0) AS FLOAT64)) AS cost_at_list,
  SUM(CAST(cost_before_discounts AS FLOAT64)) AS cost_before_discounts,
  SUM(CAST(IFNULL(cud_credits, 0) AS FLOAT64)) AS cud_credits,
  SUM(CAST(IFNULL(other_credits, 0) AS FLOAT64)) AS other_credits,
  SUM(CAST(cost_after_credits AS FLOAT64)) AS cost_after_credits,
  FORMAT_TIMESTAMP('%Y-%m-%dT%H:%M:%SZ', MAX(latest_usage_time)) AS latest_usage_time,
  ANY_VALUE(NULLIF(region, '')) AS region
FROM \`${project}.${dataset}.${table}\`
WHERE usage_date >= DATE_TRUNC(CURRENT_DATE(), MONTH)
  AND project_id = @projectId
  AND service_description = @serviceDescription
GROUP BY resource_label
ORDER BY cost_after_credits DESC
LIMIT 25`;
}
function buildServiceBreakdownParameters(list) {
  return [
    {
      name: "projectId",
      parameterType: { type: "STRING" },
      parameterValue: { value: list.projectId }
    },
    {
      name: "serviceDescription",
      parameterType: { type: "STRING" },
      parameterValue: { value: SERVICE_DESCRIPTION_MAP[list.serviceType] }
    }
  ];
}
function buildProjectOverviewQuery(target) {
  const project = target.billingProjectId.trim();
  const dataset = target.datasetName.trim();
  const table = target.summaryTableName.trim();
  return `SELECT
  COALESCE(NULLIF(service_description, ''), '(other)') AS service_description,
  ANY_VALUE(currency) AS currency,
  SUM(CAST(IFNULL(cost_at_list, 0) AS FLOAT64)) AS cost_at_list,
  SUM(CAST(cost_before_discounts AS FLOAT64)) AS cost_before_discounts,
  SUM(CAST(IFNULL(cud_credits, 0) AS FLOAT64)) AS cud_credits,
  SUM(CAST(IFNULL(other_credits, 0) AS FLOAT64)) AS other_credits,
  SUM(CAST(cost_after_credits AS FLOAT64)) AS cost_after_credits,
  FORMAT_TIMESTAMP('%Y-%m-%dT%H:%M:%SZ', MAX(latest_usage_time)) AS latest_usage_time
FROM \`${project}.${dataset}.${table}\`
WHERE usage_date >= DATE_TRUNC(CURRENT_DATE(), MONTH)
  AND project_id = @projectId
GROUP BY service_description
ORDER BY cost_after_credits DESC
LIMIT 25`;
}
function buildProjectOverviewParameters(projectId) {
  return [
    {
      name: "projectId",
      parameterType: { type: "STRING" },
      parameterValue: { value: projectId }
    }
  ];
}

// src/core/billing/client.ts
function mapBigQueryRows(response) {
  if (!response.rows || response.rows.length === 0) {
    return [];
  }
  return response.rows.map((row) => {
    const cells = row.f ?? [];
    const usageDate = cells[0]?.v ?? "";
    if (!usageDate) {
      return null;
    }
    return {
      usageDate,
      currency: cells[1]?.v ?? "USD",
      costAtList: Number(cells[2]?.v ?? 0) || 0,
      costBeforeDiscounts: Number(cells[3]?.v ?? 0) || 0,
      cudCredits: Number(cells[4]?.v ?? 0) || 0,
      otherCredits: Number(cells[5]?.v ?? 0) || 0,
      costAfterCredits: Number(cells[6]?.v ?? 0) || 0,
      latestUsageTime: cells[7]?.v ?? null
    };
  }).filter((row) => row !== null);
}
function aggregateGroupedRows(rawRows, fallbackLabel) {
  let currency = "USD";
  let listPrice = 0;
  let totalBeforeDiscounts = 0;
  let cudCredits = 0;
  let otherCredits = 0;
  let totalAfterCredits = 0;
  let latestUsageTime = null;
  const items = [];
  for (const row of rawRows) {
    const cells = row.f ?? [];
    const resourceName = cells[0]?.v ?? fallbackLabel;
    const rowCurrency = cells[1]?.v ?? "USD";
    const rowList = Number(cells[2]?.v ?? 0) || 0;
    const before = Number(cells[3]?.v ?? 0) || 0;
    const cud = Number(cells[4]?.v ?? 0) || 0;
    const other = Number(cells[5]?.v ?? 0) || 0;
    const after = Number(cells[6]?.v ?? 0) || 0;
    const usageTime = cells[7]?.v ?? null;
    const region = cells[8]?.v ?? null;
    currency = rowCurrency;
    listPrice += rowList > 0 ? rowList : before;
    totalBeforeDiscounts += before;
    cudCredits += cud;
    otherCredits += other;
    totalAfterCredits += after;
    if (usageTime && (!latestUsageTime || usageTime > latestUsageTime)) {
      latestUsageTime = usageTime;
    }
    items.push({
      resourceName,
      region,
      currency: rowCurrency,
      costBeforeDiscounts: before,
      cudCredits: cud,
      otherCredits: other,
      costAfterCredits: after
    });
  }
  const contractDiscount = Math.max(0, listPrice - totalBeforeDiscounts);
  const totalSavings = Math.max(0, listPrice - totalAfterCredits);
  const savingsPercent = listPrice > 0 ? totalSavings / listPrice * 100 : null;
  return {
    currency,
    listPrice,
    contractDiscount,
    totalBeforeDiscounts,
    cudCredits,
    otherCredits,
    totalAfterCredits,
    totalSavings,
    savingsPercent,
    items,
    latestUsageTime,
    fetchedAt: Date.now(),
    fromCache: false
  };
}
async function executeBigQueryQuery(projectId, sql, queryParameters, accessToken, fetchFn) {
  const endpoint = `https://bigquery.googleapis.com/bigquery/v2/projects/${encodeURIComponent(projectId.trim())}/queries`;
  const response = await fetchFn(endpoint, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      query: sql,
      useLegacySql: false,
      parameterMode: "NAMED",
      queryParameters,
      timeoutMs: 15e3
    })
  });
  if (!response.ok) {
    return {
      ok: false,
      message: mapHttpErrorToMessage(response.status),
      unauthorized: response.status === 401
    };
  }
  return {
    ok: true,
    response: await response.json()
  };
}
async function fetchResourceCostSummary(target, resource, accessToken, fetchFn = fetch, referenceDate = /* @__PURE__ */ new Date()) {
  const validation = validateBigQueryTarget(target);
  if (!validation.ok) {
    return { status: "error", message: validation.message };
  }
  try {
    const resourceQuery = await executeBigQueryQuery(
      target.billingProjectId,
      buildResourceCostQuery(target, true),
      buildQueryParameters(resource, true),
      accessToken,
      fetchFn
    );
    if (!resourceQuery.ok) {
      return {
        status: "error",
        message: resourceQuery.message,
        unauthorized: resourceQuery.unauthorized
      };
    }
    const resourceRows = mapBigQueryRows(resourceQuery.response);
    if (resourceRows.length > 0) {
      return {
        status: "loaded",
        summary: summarizeBillingRows(
          resourceRows,
          "this resource",
          referenceDate
        )
      };
    }
    const projectQuery = await executeBigQueryQuery(
      target.billingProjectId,
      buildResourceCostQuery(target, false),
      buildQueryParameters(resource, false),
      accessToken,
      fetchFn
    );
    if (!projectQuery.ok) {
      return {
        status: "error",
        message: projectQuery.message,
        unauthorized: projectQuery.unauthorized
      };
    }
    const projectRows = mapBigQueryRows(projectQuery.response);
    if (projectRows.length > 0) {
      return {
        status: "loaded",
        summary: summarizeBillingRows(
          projectRows,
          "project share",
          referenceDate
        )
      };
    }
    return { status: "no_data" };
  } catch {
    return {
      status: "error",
      message: "Could not reach BigQuery. Check your internet connection and try again."
    };
  }
}
async function fetchGroupedBreakdown(target, sql, params, fallbackLabel, accessToken, fetchFn) {
  const validation = validateBigQueryTarget(target);
  if (!validation.ok) {
    return { status: "error", message: validation.message };
  }
  try {
    const queryResult = await executeBigQueryQuery(
      target.billingProjectId,
      sql,
      params,
      accessToken,
      fetchFn
    );
    if (!queryResult.ok) {
      return {
        status: "error",
        message: queryResult.message,
        unauthorized: queryResult.unauthorized
      };
    }
    const rawRows = queryResult.response.rows ?? [];
    if (rawRows.length === 0) {
      return { status: "no_data" };
    }
    return {
      status: "loaded",
      breakdown: aggregateGroupedRows(rawRows, fallbackLabel)
    };
  } catch {
    return {
      status: "error",
      message: "Could not reach BigQuery. Check your internet connection and try again."
    };
  }
}
function fetchServiceBreakdown(target, list, accessToken, fetchFn = fetch) {
  return fetchGroupedBreakdown(
    target,
    buildServiceBreakdownQuery(target),
    buildServiceBreakdownParameters(list),
    "(project-level)",
    accessToken,
    fetchFn
  );
}
function fetchProjectOverview(target, projectId, accessToken, fetchFn = fetch) {
  return fetchGroupedBreakdown(
    target,
    buildProjectOverviewQuery(target),
    buildProjectOverviewParameters(projectId),
    "(other)",
    accessToken,
    fetchFn
  );
}

// src/core/insights/index.ts
function checkHighSpendAlert(amount, currency, threshold) {
  if (threshold <= 0 || amount < threshold) {
    return null;
  }
  return {
    id: "high-spend-alert",
    severity: "warning",
    title: "Action required: Spend exceeds monthly alert",
    detail: `Current spend (${formatMoney(amount, currency)}) is above your ${formatMoney(threshold, currency)}/month threshold.`,
    action: "Review scaling limits, idle instances, or traffic drivers."
  };
}
function checkNoCudCoverage(serviceType, beforeDiscounts, cudCredits, currency) {
  if (serviceType === "cloud-storage" || serviceType === "bigquery" || beforeDiscounts < 50 || Math.abs(cudCredits) > 0.01) {
    return null;
  }
  return {
    id: "no-cud-coverage",
    severity: "info",
    title: "No CUD coverage detected",
    detail: `${formatMoney(beforeDiscounts, currency)} this month has $0 in Committed Use Discounts.`,
    action: "Evaluate 1-year or 3-year CUDs if this workload is steady."
  };
}
function checkCreditsMaskingSpend(summary) {
  if (summary.thisMonthBeforeDiscounts <= 0) {
    return null;
  }
  const creditAmount = summary.thisMonthBeforeDiscounts - summary.thisMonthAfterCredits;
  const creditRatio = creditAmount / summary.thisMonthBeforeDiscounts;
  if (creditRatio < 0.8) {
    return null;
  }
  const pct = Math.min(100, Math.round(creditRatio * 100));
  return {
    id: "credits-masking-spend",
    severity: "info",
    title: "Credits cover most of this cost",
    detail: `${pct}% is covered by credits right now (${formatMoney(summary.thisMonthBeforeDiscounts, summary.currency)} before discounts).`,
    action: "Plan ahead for when promotional or trial credits expire."
  };
}
function checkAlwaysOnFlatCost(summary, resource) {
  const activeDays = summary.dailySeries.map((point) => point.costBeforeDiscounts).filter((cost) => cost > 0.01);
  if (activeDays.length < 14) {
    return null;
  }
  const min = Math.min(...activeDays);
  const max = Math.max(...activeDays);
  const avg = activeDays.reduce((sum, v) => sum + v, 0) / activeDays.length;
  if (avg <= 0 || (max - min) / avg > 0.15) {
    return null;
  }
  const action = resource.serviceType === "cloud-run" ? "Set min-instances to 0 if traffic can tolerate cold starts." : resource.serviceType === "compute-engine" ? "Stop or right-size this VM outside active hours." : "Review storage class lifecycle rules.";
  return {
    id: "always-on-flat-cost",
    severity: "warning",
    title: "Action required: Always-on daily cost",
    detail: `Steady spend (~${formatMoney(avg, summary.currency)}/day) on ${activeDays.length} of the last 30 days.`,
    action
  };
}
function checkRecentSpendSpike(summary) {
  const nonZeroDays = summary.dailySeries.map((point) => point.costBeforeDiscounts).filter((cost) => cost > 0);
  if (nonZeroDays.length < 3) {
    return null;
  }
  const latest = summary.dailySeries[summary.dailySeries.length - 1];
  if (!latest || latest.costBeforeDiscounts <= 0.5) {
    return null;
  }
  const avg = nonZeroDays.reduce((sum, v) => sum + v, 0) / nonZeroDays.length;
  if (latest.costBeforeDiscounts <= avg * 2) {
    return null;
  }
  return {
    id: "recent-spend-spike",
    severity: "warning",
    title: "Action required: Recent daily spend spike",
    detail: `${latest.date} was ${formatMoney(latest.costBeforeDiscounts, summary.currency)} vs ${formatMoney(avg, summary.currency)} daily average.`,
    action: "Check recent deployments, traffic spikes, or runaway jobs."
  };
}
function evaluateCostInsights(summary, resource, monthlyAlertThreshold = 0) {
  const candidates = [
    checkHighSpendAlert(
      summary.thisMonthAfterCredits,
      summary.currency,
      monthlyAlertThreshold
    ),
    checkRecentSpendSpike(summary),
    checkAlwaysOnFlatCost(summary, resource),
    checkCreditsMaskingSpend(summary),
    checkNoCudCoverage(
      resource.serviceType,
      summary.thisMonthBeforeDiscounts,
      summary.thisMonthCudCredits,
      summary.currency
    )
  ];
  return candidates.filter((item) => item !== null);
}
function evaluateListInsights(breakdown, list, monthlyAlertThreshold = 0) {
  const candidates = [
    checkHighSpendAlert(
      breakdown.totalAfterCredits,
      breakdown.currency,
      monthlyAlertThreshold
    ),
    checkNoCudCoverage(
      list.serviceType,
      breakdown.totalBeforeDiscounts,
      breakdown.cudCredits,
      breakdown.currency
    )
  ];
  return candidates.filter((item) => item !== null);
}
function evaluateProjectInsights(breakdown, monthlyAlertThreshold = 0) {
  const candidates = [
    checkHighSpendAlert(
      breakdown.totalAfterCredits,
      breakdown.currency,
      monthlyAlertThreshold
    ),
    checkNoCudCoverage(
      "compute-engine",
      breakdown.totalBeforeDiscounts,
      breakdown.cudCredits,
      breakdown.currency
    )
  ];
  return candidates.filter((item) => item !== null);
}

// src/core/url/utils.ts
function decodeSegment(raw) {
  if (!raw) {
    return null;
  }
  try {
    const decoded = decodeURIComponent(raw).trim();
    return decoded.length > 0 ? decoded : null;
  } catch {
    return null;
  }
}
function getPathSegments(pathname) {
  return pathname.split("/").filter((segment) => segment.length > 0);
}

// src/core/url/cloudRun.ts
function parseCloudRunSegments(segments, projectId) {
  if (segments[0] !== "run" || segments[1] !== "detail") {
    return null;
  }
  const region = decodeSegment(segments[2]);
  const serviceName = decodeSegment(segments[3]);
  if (!region || !serviceName) {
    return null;
  }
  return {
    projectId,
    serviceType: "cloud-run",
    regionOrZone: region,
    resourceName: serviceName
  };
}

// src/core/url/cloudSql.ts
function parseCloudSqlSegments(segments, projectId) {
  if (segments[0] !== "sql" || segments[1] !== "instances") {
    return null;
  }
  const instanceName = decodeSegment(segments[2]);
  if (!instanceName) {
    return null;
  }
  return {
    projectId,
    serviceType: "cloud-sql",
    regionOrZone: null,
    resourceName: instanceName
  };
}

// src/core/url/cloudStorage.ts
function parseCloudStorageSegments(segments, projectId) {
  if (segments[0] !== "storage" || segments[1] !== "browser") {
    return null;
  }
  const bucketSegment = segments[2] === "_details" ? segments[3] : segments[2];
  const bucketName = decodeSegment(bucketSegment);
  if (!bucketName) {
    return null;
  }
  return {
    projectId,
    serviceType: "cloud-storage",
    regionOrZone: null,
    resourceName: bucketName
  };
}

// src/core/url/computeEngine.ts
function parseComputeEngineSegments(segments, projectId) {
  if (segments[0] !== "compute" || segments[1] !== "instancesDetail" || segments[2] !== "zones" || segments[4] !== "instances") {
    return null;
  }
  const zone = decodeSegment(segments[3]);
  const instanceName = decodeSegment(segments[5]);
  if (!zone || !instanceName) {
    return null;
  }
  return {
    projectId,
    serviceType: "compute-engine",
    regionOrZone: zone,
    resourceName: instanceName
  };
}

// src/core/url/gke.ts
function parseGkeSegments(segments, projectId) {
  if (segments[0] !== "kubernetes" || segments[1] !== "clusters" || segments[2] !== "details") {
    return null;
  }
  const location = decodeSegment(segments[3]);
  const clusterName = decodeSegment(segments[4]);
  if (!location || !clusterName) {
    return null;
  }
  return {
    projectId,
    serviceType: "gke",
    regionOrZone: location,
    resourceName: clusterName
  };
}

// src/core/url/index.ts
var CONSOLE_ORIGIN = "https://console.cloud.google.com";
var SERVICE_PARSERS = [
  parseCloudRunSegments,
  parseComputeEngineSegments,
  parseCloudStorageSegments,
  parseGkeSegments,
  parseCloudSqlSegments
];
function parseConsoleBase(rawUrl) {
  let parsed;
  try {
    parsed = new URL(rawUrl);
  } catch {
    return null;
  }
  if (parsed.origin !== CONSOLE_ORIGIN) {
    return null;
  }
  const projectId = parsed.searchParams.get("project")?.trim();
  if (!projectId) {
    return null;
  }
  return {
    projectId,
    segments: getPathSegments(parsed.pathname)
  };
}
function parseServiceListSegments(segments, projectId) {
  if (segments[0] === "run" && (segments.length === 1 || segments[1] === "services" || segments[1] === "overview" || segments[1] === "jobs")) {
    return { projectId, serviceType: "cloud-run" };
  }
  if (segments.length === 2 && segments[0] === "compute" && segments[1] === "instances") {
    return { projectId, serviceType: "compute-engine" };
  }
  if (segments.length === 2 && segments[0] === "storage" && segments[1] === "browser") {
    return { projectId, serviceType: "cloud-storage" };
  }
  if (segments[0] === "kubernetes" && (segments[1] === "clusters" || segments[1] === "list")) {
    return { projectId, serviceType: "gke" };
  }
  if (segments[0] === "bigquery") {
    return { projectId, serviceType: "bigquery" };
  }
  if (segments[0] === "vertex-ai") {
    return { projectId, serviceType: "vertex-ai" };
  }
  if (segments.length === 2 && segments[0] === "sql" && segments[1] === "instances") {
    return { projectId, serviceType: "cloud-sql" };
  }
  if (segments[0] === "cloudpubsub") {
    return { projectId, serviceType: "pubsub" };
  }
  if (segments[0] === "artifacts") {
    return { projectId, serviceType: "artifact-registry" };
  }
  return null;
}
function parseProjectHomeSegments(segments, projectId) {
  if (segments[0] === "home" && segments[1] === "dashboard" || segments[0] === "welcome") {
    return { projectId };
  }
  return null;
}
function parseConsoleTarget(rawUrl) {
  const base = parseConsoleBase(rawUrl);
  if (!base) {
    return "unsupported";
  }
  for (const parseService of SERVICE_PARSERS) {
    const match = parseService(base.segments, base.projectId);
    if (match) {
      return { kind: "resource", resource: match };
    }
  }
  const listMatch = parseServiceListSegments(base.segments, base.projectId);
  if (listMatch) {
    return { kind: "service-list", list: listMatch };
  }
  const homeMatch = parseProjectHomeSegments(base.segments, base.projectId);
  if (homeMatch) {
    return { kind: "project-home", project: homeMatch };
  }
  return "unsupported";
}

// src/shared/settings.ts
var SETTINGS_STORAGE_KEY = "kanakku_settings";
var DEFAULT_SETTINGS = {
  billingProjectId: "",
  datasetName: "",
  summaryTableName: "",
  cacheMinutes: 60,
  monthlyAlertThreshold: 0,
  aiExplanationsEnabled: false,
  geminiApiKey: ""
};
function normalizeSettings(raw) {
  const cacheMinutes = typeof raw?.cacheMinutes === "number" && Number.isFinite(raw.cacheMinutes) && raw.cacheMinutes > 0 ? Math.round(raw.cacheMinutes) : DEFAULT_SETTINGS.cacheMinutes;
  const monthlyAlertThreshold = typeof raw?.monthlyAlertThreshold === "number" && Number.isFinite(raw.monthlyAlertThreshold) && raw.monthlyAlertThreshold > 0 ? Math.round(raw.monthlyAlertThreshold * 100) / 100 : DEFAULT_SETTINGS.monthlyAlertThreshold;
  return {
    billingProjectId: (raw?.billingProjectId ?? "").trim(),
    datasetName: (raw?.datasetName ?? "").trim(),
    summaryTableName: (raw?.summaryTableName ?? "").trim(),
    cacheMinutes,
    monthlyAlertThreshold,
    aiExplanationsEnabled: Boolean(raw?.aiExplanationsEnabled),
    geminiApiKey: (raw?.geminiApiKey ?? "").trim()
  };
}
async function loadSettings() {
  const stored = await chrome.storage.local.get(SETTINGS_STORAGE_KEY);
  return normalizeSettings(
    stored[SETTINGS_STORAGE_KEY]
  );
}
async function saveSettings(settings) {
  const normalized = normalizeSettings(settings);
  await chrome.storage.local.set({ [SETTINGS_STORAGE_KEY]: normalized });
  return normalized;
}

// src/background/panel.ts
async function enableActionClickSidePanel(sidePanelApi = globalThis.chrome?.sidePanel) {
  if (!sidePanelApi) {
    return;
  }
  await sidePanelApi.setPanelBehavior({ openPanelOnActionClick: true });
}

// src/background/index.ts
void enableActionClickSidePanel().catch((error) => {
  console.error("Failed to configure side panel behavior:", error);
});
async function getAccessToken(interactive) {
  try {
    const result = await chrome.identity.getAuthToken({ interactive });
    return result.token ?? null;
  } catch {
    return null;
  }
}
async function evictExpiredToken(token) {
  try {
    await chrome.identity.removeCachedAuthToken({ token });
  } catch {
  }
}
async function resolveCostStateForUrl(url, forceRefresh = false) {
  const parsed = url ? parseConsoleTarget(url) : "unsupported";
  if (parsed === "unsupported") {
    return { status: "unsupported" };
  }
  const target = parsed;
  const settings = await loadSettings();
  if (!settings.billingProjectId || !settings.datasetName || !settings.summaryTableName) {
    return { status: "missing_settings", target };
  }
  const aiConfig = {
    enabled: settings.aiExplanationsEnabled,
    apiKey: settings.geminiApiKey
  };
  if (target.kind === "resource") {
    const cacheKey = buildCacheKey(target.resource);
    let summary = !forceRefresh ? await getCachedSummary(cacheKey) : null;
    if (!summary) {
      const token = await getAccessToken(false);
      if (!token) {
        return { status: "not_signed_in", target };
      }
      const result = await fetchResourceCostSummary(
        settings,
        target.resource,
        token
      );
      if (result.status === "no_data") {
        return { status: "no_data", target };
      }
      if (result.status === "error") {
        if (result.unauthorized) {
          await evictExpiredToken(token);
          return { status: "not_signed_in", target };
        }
        return { status: "error", target, message: result.message };
      }
      summary = result.summary;
      await setCachedSummary(cacheKey, summary, settings.cacheMinutes);
    }
    const insights = evaluateCostInsights(
      summary,
      target.resource,
      settings.monthlyAlertThreshold
    );
    const executiveSummary2 = await generateExecutiveSummary(
      {
        title: `${target.resource.resourceName} (${target.resource.serviceType})`,
        projectId: target.resource.projectId,
        currency: summary.currency,
        listPrice: summary.thisMonthListPrice,
        cudCredits: summary.thisMonthCudCredits,
        totalSavings: summary.totalSavings,
        finalPrice: summary.thisMonthAfterCredits,
        percentChange: summary.percentChange,
        insights
      },
      aiConfig
    );
    return {
      status: "loaded",
      resource: target.resource,
      summary,
      monthlyAlertThreshold: settings.monthlyAlertThreshold,
      executiveSummary: executiveSummary2
    };
  }
  if (target.kind === "service-list") {
    const listCacheKey = buildListCacheKey(target.list);
    let breakdown = !forceRefresh ? await getCachedBreakdown(listCacheKey) : null;
    if (!breakdown) {
      const token = await getAccessToken(false);
      if (!token) {
        return { status: "not_signed_in", target };
      }
      const listResult = await fetchServiceBreakdown(
        settings,
        target.list,
        token
      );
      if (listResult.status === "no_data") {
        return { status: "no_data", target };
      }
      if (listResult.status === "error") {
        if (listResult.unauthorized) {
          await evictExpiredToken(token);
          return { status: "not_signed_in", target };
        }
        return { status: "error", target, message: listResult.message };
      }
      breakdown = listResult.breakdown;
      await setCachedBreakdown(listCacheKey, breakdown, settings.cacheMinutes);
    }
    const insights = evaluateListInsights(
      breakdown,
      target.list,
      settings.monthlyAlertThreshold
    );
    const executiveSummary2 = await generateExecutiveSummary(
      {
        title: `${target.list.serviceType} overview`,
        projectId: target.list.projectId,
        currency: breakdown.currency,
        listPrice: breakdown.listPrice,
        cudCredits: breakdown.cudCredits,
        totalSavings: breakdown.totalSavings,
        finalPrice: breakdown.totalAfterCredits,
        percentChange: null,
        insights
      },
      aiConfig
    );
    return {
      status: "loaded_list",
      list: target.list,
      breakdown,
      monthlyAlertThreshold: settings.monthlyAlertThreshold,
      executiveSummary: executiveSummary2
    };
  }
  const projectCacheKey = buildProjectCacheKey(target.project.projectId);
  let projectBreakdown = !forceRefresh ? await getCachedBreakdown(projectCacheKey) : null;
  if (!projectBreakdown) {
    const token = await getAccessToken(false);
    if (!token) {
      return { status: "not_signed_in", target };
    }
    const projectResult = await fetchProjectOverview(
      settings,
      target.project.projectId,
      token
    );
    if (projectResult.status === "no_data") {
      return { status: "no_data", target };
    }
    if (projectResult.status === "error") {
      if (projectResult.unauthorized) {
        await evictExpiredToken(token);
        return { status: "not_signed_in", target };
      }
      return { status: "error", target, message: projectResult.message };
    }
    projectBreakdown = projectResult.breakdown;
    await setCachedBreakdown(
      projectCacheKey,
      projectBreakdown,
      settings.cacheMinutes
    );
  }
  const projectInsights = evaluateProjectInsights(
    projectBreakdown,
    settings.monthlyAlertThreshold
  );
  const executiveSummary = await generateExecutiveSummary(
    {
      title: "All project services",
      projectId: target.project.projectId,
      currency: projectBreakdown.currency,
      listPrice: projectBreakdown.listPrice,
      cudCredits: projectBreakdown.cudCredits,
      totalSavings: projectBreakdown.totalSavings,
      finalPrice: projectBreakdown.totalAfterCredits,
      percentChange: null,
      insights: projectInsights
    },
    aiConfig
  );
  return {
    status: "loaded_project",
    project: target.project,
    breakdown: projectBreakdown,
    monthlyAlertThreshold: settings.monthlyAlertThreshold,
    executiveSummary
  };
}
async function getActiveTabCostState(forceRefresh = false) {
  const [activeTab] = await chrome.tabs.query({
    active: true,
    lastFocusedWindow: true
  });
  return resolveCostStateForUrl(activeTab?.url, forceRefresh);
}
function broadcastCostState(url) {
  void resolveCostStateForUrl(url).then((state) => {
    const message = { type: "COST_STATE_CHANGED", state };
    return chrome.runtime.sendMessage(message).catch(() => void 0);
  }).catch(() => void 0);
}
async function handleGetAuthStatus() {
  const token = await getAccessToken(false);
  return token ? { signedIn: true, message: "Signed in with Google (read-only BigQuery)." } : { signedIn: false, message: "Not signed in." };
}
async function handleSignIn() {
  const manifest = chrome.runtime.getManifest();
  const clientId = manifest.oauth2?.client_id ?? "";
  if (!clientId || clientId === "__OAUTH_CLIENT_ID__") {
    return {
      signedIn: false,
      message: "OAuth client ID is not configured. Add oauth.local.json and rebuild (see docs/setup-guide.md)."
    };
  }
  const token = await getAccessToken(true);
  return token ? { signedIn: true, message: "Signed in with Google (read-only BigQuery)." } : {
    signedIn: false,
    message: "Google sign-in was cancelled or failed. Please try again."
  };
}
async function handleClearAllData() {
  await chrome.storage.local.clear();
  if (typeof chrome.identity.clearAllCachedAuthTokens === "function") {
    await chrome.identity.clearAllCachedAuthTokens();
  }
  return {
    ok: true,
    message: "Cleared all saved settings, cached data, and sign-in tokens."
  };
}
chrome.tabs.onActivated.addListener(({ tabId }) => {
  void chrome.tabs.get(tabId).then((tab) => broadcastCostState(tab.url)).catch(() => broadcastCostState(void 0));
});
chrome.tabs.onUpdated.addListener((_tabId, changeInfo, tab) => {
  if (!tab.active || !changeInfo.url) {
    return;
  }
  broadcastCostState(changeInfo.url);
});
chrome.runtime.onMessage.addListener(
  (message, _sender, sendResponse) => {
    switch (message?.type) {
      case "GET_SIDE_PANEL_STATE":
        void getActiveTabCostState(Boolean(message.forceRefresh)).then((state) => sendResponse(state)).catch(() => sendResponse({ status: "unsupported" }));
        return true;
      case "OPEN_OPTIONS":
        void chrome.runtime.openOptionsPage();
        return false;
      case "GET_AUTH_STATUS":
        void handleGetAuthStatus().then((status) => sendResponse(status)).catch(
          () => sendResponse({ signedIn: false, message: "Not signed in." })
        );
        return true;
      case "SIGN_IN":
        void handleSignIn().then((status) => sendResponse(status)).catch(
          () => sendResponse({
            signedIn: false,
            message: "Google sign-in failed. Please try again."
          })
        );
        return true;
      case "TEST_CONNECTION":
        void (async () => {
          const saved = await saveSettings(message.settings);
          const token = await getAccessToken(false);
          if (!token) {
            return {
              ok: false,
              message: "Please sign in with Google first."
            };
          }
          return testBigQueryConnection(saved, token);
        })().then((result) => sendResponse(result)).catch(
          () => sendResponse({
            ok: false,
            message: "Could not test the connection. Please try again."
          })
        );
        return true;
      case "CLEAR_ALL_DATA":
        void handleClearAllData().then((result) => sendResponse(result)).catch(
          () => sendResponse({
            ok: false,
            message: "Failed to clear local data. Please try again."
          })
        );
        return true;
      default:
        return false;
    }
  }
);
