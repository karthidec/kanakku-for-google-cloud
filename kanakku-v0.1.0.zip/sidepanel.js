// src/core/format/index.ts
function formatMoney(amount, currency) {
  const code = currency || "USD";
  try {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: code,
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(amount);
  } catch {
    return `${code} ${amount.toFixed(2)}`;
  }
}
function formatPercentChange(percent) {
  if (percent === null || !Number.isFinite(percent)) {
    return "No prior month baseline";
  }
  const rounded = Math.round(percent);
  const sign = rounded > 0 ? "+" : "";
  return `${sign}${rounded}% vs last month`;
}
function formatFreshness(isoTimestamp, nowMs = Date.now()) {
  if (!isoTimestamp) {
    return "freshness unknown";
  }
  const parsedMs = Date.parse(isoTimestamp);
  if (!Number.isFinite(parsedMs)) {
    return "freshness unknown";
  }
  const diffMinutes = Math.max(0, Math.floor((nowMs - parsedMs) / 6e4));
  if (diffMinutes < 60) {
    const unit2 = diffMinutes === 1 ? "minute" : "minutes";
    return `as of ${diffMinutes} ${unit2} ago`;
  }
  const diffHours = Math.floor(diffMinutes / 60);
  if (diffHours < 48) {
    const unit2 = diffHours === 1 ? "hour" : "hours";
    return `as of ${diffHours} ${unit2} ago`;
  }
  const diffDays = Math.floor(diffHours / 24);
  const unit = diffDays === 1 ? "day" : "days";
  return `as of ${diffDays} ${unit} ago`;
}

// src/core/insights/index.ts
function estimateMonthEndCost(summary, referenceDate = /* @__PURE__ */ new Date()) {
  if (summary.thisMonthAfterCredits <= 0) {
    return null;
  }
  const dayOfMonth = Math.max(1, referenceDate.getUTCDate());
  const daysInMonth = new Date(
    Date.UTC(
      referenceDate.getUTCFullYear(),
      referenceDate.getUTCMonth() + 1,
      0
    )
  ).getUTCDate();
  return summary.thisMonthAfterCredits / dayOfMonth * daysInMonth;
}
function estimateBurnRate(summary) {
  const recent = summary.dailySeries.slice(-7);
  const activeAfter = recent.map((p) => p.costAfterCredits).filter((cost) => cost > 0);
  if (activeAfter.length > 0) {
    const daily2 = activeAfter.reduce((sum, v) => sum + v, 0) / activeAfter.length;
    return { daily: daily2, hourly: daily2 / 24, beforeCreditsOnly: false };
  }
  const activeBefore = recent.map((p) => p.costBeforeDiscounts).filter((cost) => cost > 0);
  if (activeBefore.length === 0) {
    return null;
  }
  const daily = activeBefore.reduce((sum, v) => sum + v, 0) / activeBefore.length;
  return { daily, hourly: daily / 24, beforeCreditsOnly: true };
}
function checkHighSpendAlert(amount, currency, threshold) {
  if (threshold <= 0 || amount < threshold) {
    return null;
  }
  return {
    id: "high-spend-alert",
    severity: "warning",
    title: "Action required: Spend exceeds monthly alert",
    detail: `Current spend (${formatMoney(amount, currency)}) is above your ${formatMoney(threshold, currency)}/month threshold.`,
    action: "Review scaling limits, idle instances, or traffic drivers."
  };
}
function checkNoCudCoverage(serviceType, beforeDiscounts, cudCredits, currency) {
  if (serviceType === "cloud-storage" || serviceType === "bigquery" || beforeDiscounts < 50 || Math.abs(cudCredits) > 0.01) {
    return null;
  }
  return {
    id: "no-cud-coverage",
    severity: "info",
    title: "No CUD coverage detected",
    detail: `${formatMoney(beforeDiscounts, currency)} this month has $0 in Committed Use Discounts.`,
    action: "Evaluate 1-year or 3-year CUDs if this workload is steady."
  };
}
function checkCreditsMaskingSpend(summary) {
  if (summary.thisMonthBeforeDiscounts <= 0) {
    return null;
  }
  const creditAmount = summary.thisMonthBeforeDiscounts - summary.thisMonthAfterCredits;
  const creditRatio = creditAmount / summary.thisMonthBeforeDiscounts;
  if (creditRatio < 0.8) {
    return null;
  }
  const pct = Math.min(100, Math.round(creditRatio * 100));
  return {
    id: "credits-masking-spend",
    severity: "info",
    title: "Credits cover most of this cost",
    detail: `${pct}% is covered by credits right now (${formatMoney(summary.thisMonthBeforeDiscounts, summary.currency)} before discounts).`,
    action: "Plan ahead for when promotional or trial credits expire."
  };
}
function checkAlwaysOnFlatCost(summary, resource) {
  const activeDays = summary.dailySeries.map((point) => point.costBeforeDiscounts).filter((cost) => cost > 0.01);
  if (activeDays.length < 14) {
    return null;
  }
  const min = Math.min(...activeDays);
  const max = Math.max(...activeDays);
  const avg = activeDays.reduce((sum, v) => sum + v, 0) / activeDays.length;
  if (avg <= 0 || (max - min) / avg > 0.15) {
    return null;
  }
  const action = resource.serviceType === "cloud-run" ? "Set min-instances to 0 if traffic can tolerate cold starts." : resource.serviceType === "compute-engine" ? "Stop or right-size this VM outside active hours." : "Review storage class lifecycle rules.";
  return {
    id: "always-on-flat-cost",
    severity: "warning",
    title: "Action required: Always-on daily cost",
    detail: `Steady spend (~${formatMoney(avg, summary.currency)}/day) on ${activeDays.length} of the last 30 days.`,
    action
  };
}
function checkRecentSpendSpike(summary) {
  const nonZeroDays = summary.dailySeries.map((point) => point.costBeforeDiscounts).filter((cost) => cost > 0);
  if (nonZeroDays.length < 3) {
    return null;
  }
  const latest = summary.dailySeries[summary.dailySeries.length - 1];
  if (!latest || latest.costBeforeDiscounts <= 0.5) {
    return null;
  }
  const avg = nonZeroDays.reduce((sum, v) => sum + v, 0) / nonZeroDays.length;
  if (latest.costBeforeDiscounts <= avg * 2) {
    return null;
  }
  return {
    id: "recent-spend-spike",
    severity: "warning",
    title: "Action required: Recent daily spend spike",
    detail: `${latest.date} was ${formatMoney(latest.costBeforeDiscounts, summary.currency)} vs ${formatMoney(avg, summary.currency)} daily average.`,
    action: "Check recent deployments, traffic spikes, or runaway jobs."
  };
}
function evaluateCostInsights(summary, resource, monthlyAlertThreshold = 0) {
  const candidates = [
    checkHighSpendAlert(
      summary.thisMonthAfterCredits,
      summary.currency,
      monthlyAlertThreshold
    ),
    checkRecentSpendSpike(summary),
    checkAlwaysOnFlatCost(summary, resource),
    checkCreditsMaskingSpend(summary),
    checkNoCudCoverage(
      resource.serviceType,
      summary.thisMonthBeforeDiscounts,
      summary.thisMonthCudCredits,
      summary.currency
    )
  ];
  return candidates.filter((item) => item !== null);
}
function evaluateListInsights(breakdown, list, monthlyAlertThreshold = 0) {
  const candidates = [
    checkHighSpendAlert(
      breakdown.totalAfterCredits,
      breakdown.currency,
      monthlyAlertThreshold
    ),
    checkNoCudCoverage(
      list.serviceType,
      breakdown.totalBeforeDiscounts,
      breakdown.cudCredits,
      breakdown.currency
    )
  ];
  return candidates.filter((item) => item !== null);
}
function evaluateProjectInsights(breakdown, monthlyAlertThreshold = 0) {
  const candidates = [
    checkHighSpendAlert(
      breakdown.totalAfterCredits,
      breakdown.currency,
      monthlyAlertThreshold
    ),
    checkNoCudCoverage(
      "compute-engine",
      breakdown.totalBeforeDiscounts,
      breakdown.cudCredits,
      breakdown.currency
    )
  ];
  return candidates.filter((item) => item !== null);
}

// src/sidepanel/chart.ts
var SVG_NS = "http://www.w3.org/2000/svg";
function renderDailyChart(container, series, currency = "USD") {
  container.replaceChildren();
  if (series.length === 0) {
    return;
  }
  const width = 260;
  const height = 56;
  const maxVal = Math.max(
    0.01,
    ...series.map((point) => Math.max(0, point.costAfterCredits))
  );
  const slotWidth = width / series.length;
  const barWidth = Math.max(2, slotWidth - 2);
  const svg = document.createElementNS(SVG_NS, "svg");
  svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
  svg.setAttribute("class", "sparkline-svg");
  svg.setAttribute("role", "img");
  svg.setAttribute("aria-label", "30-day daily cost chart");
  series.forEach((point, index) => {
    const value = Math.max(0, point.costAfterCredits);
    const barHeight = value > 0 ? Math.max(2, value / maxVal * (height - 4)) : 1;
    const rect = document.createElementNS(SVG_NS, "rect");
    rect.setAttribute("x", (index * slotWidth + 1).toFixed(1));
    rect.setAttribute("y", (height - barHeight).toFixed(1));
    rect.setAttribute("width", barWidth.toFixed(1));
    rect.setAttribute("height", barHeight.toFixed(1));
    rect.setAttribute("rx", "1");
    rect.setAttribute(
      "class",
      value > 0 ? "sparkline-bar" : "sparkline-bar-zero"
    );
    const title = document.createElementNS(SVG_NS, "title");
    title.textContent = `${point.date}: ${formatMoney(point.costAfterCredits, currency)} (${formatMoney(point.costBeforeDiscounts, currency)} before discounts)`;
    rect.appendChild(title);
    svg.appendChild(rect);
  });
  container.appendChild(svg);
}

// src/sidepanel/csv.ts
function escapeCsvCell(value) {
  const neutralized = /^[=+\-@\t\r]/.test(value) ? `'${value}` : value;
  if (/[",\n\r]/.test(neutralized)) {
    return `"${neutralized.replace(/"/g, '""')}"`;
  }
  return neutralized;
}
function buildBreakdownCsv(items) {
  const header = "Name,Region,Currency,Before Discounts,CUD Credits,Other Credits,Final Price";
  const rows = items.map(
    (item) => [
      escapeCsvCell(item.resourceName),
      escapeCsvCell(item.region ?? ""),
      escapeCsvCell(item.currency),
      item.costBeforeDiscounts.toFixed(2),
      item.cudCredits.toFixed(2),
      item.otherCredits.toFixed(2),
      item.costAfterCredits.toFixed(2)
    ].join(",")
  );
  return [header, ...rows].join("\n");
}

// src/sidepanel/messages.ts
var EMPTY_STATE_MESSAGE = "Open a Google Cloud resource to see its cost.";

// src/sidepanel/sidepanel.ts
var SERVICE_LABELS = {
  "cloud-run": "Cloud Run service",
  "compute-engine": "Compute Engine VM",
  "cloud-storage": "Cloud Storage bucket",
  gke: "GKE cluster",
  bigquery: "BigQuery",
  "vertex-ai": "Vertex AI",
  "cloud-sql": "Cloud SQL instance",
  pubsub: "Cloud Pub/Sub",
  "artifact-registry": "Artifact Registry"
};
var SERVICE_LIST_LABELS = {
  "cloud-run": "Cloud Run services",
  "compute-engine": "Compute Engine VMs",
  "cloud-storage": "Cloud Storage buckets",
  gke: "GKE clusters",
  bigquery: "BigQuery",
  "vertex-ai": "Vertex AI",
  "cloud-sql": "Cloud SQL instances",
  pubsub: "Cloud Pub/Sub",
  "artifact-registry": "Artifact Registry"
};
var lastSummaryText = "";
var lastBreakdownItems = [];
var lastCsvFilename = "kanakku-costs.csv";
function renderBudgetBar(doc, prefix, spent, threshold, currency) {
  const box = doc.getElementById(`${prefix}-budget-box`);
  const label = doc.getElementById(`${prefix}-budget-label`);
  const fill = doc.getElementById(
    `${prefix}-budget-fill`
  );
  if (!box || threshold <= 0) {
    box?.classList.add("hidden");
    return;
  }
  const pct = Math.max(0, Math.round(spent / threshold * 100));
  if (label) {
    label.textContent = `${formatMoney(spent, currency)} / ${formatMoney(threshold, currency)} (${pct}%)`;
  }
  if (fill) {
    fill.style.width = `${Math.min(100, pct)}%`;
    fill.classList.remove("warn", "over");
    if (pct >= 100) {
      fill.classList.add("over");
    } else if (pct >= 75) {
      fill.classList.add("warn");
    }
  }
  box.classList.remove("hidden");
}
function renderIdentityHeader(target, doc) {
  const serviceBadge = doc.getElementById("service-badge");
  const resourceName = doc.getElementById("resource-name");
  const resourceProject = doc.getElementById("resource-project");
  const regionRow = doc.getElementById("region-row");
  const resourceRegion = doc.getElementById("resource-region");
  const billingLink = doc.getElementById(
    "billing-link"
  );
  if (target.kind === "resource") {
    if (serviceBadge) {
      serviceBadge.textContent = SERVICE_LABELS[target.resource.serviceType];
    }
    if (resourceName) {
      resourceName.textContent = target.resource.resourceName;
    }
    if (resourceProject) {
      resourceProject.textContent = target.resource.projectId;
    }
    if (target.resource.regionOrZone) {
      if (resourceRegion) {
        resourceRegion.textContent = target.resource.regionOrZone;
      }
      regionRow?.classList.remove("hidden");
    } else {
      regionRow?.classList.add("hidden");
    }
    if (billingLink) {
      billingLink.href = `https://console.cloud.google.com/billing?project=${encodeURIComponent(target.resource.projectId)}`;
    }
    return;
  }
  if (target.kind === "service-list") {
    if (serviceBadge) {
      serviceBadge.textContent = SERVICE_LIST_LABELS[target.list.serviceType];
    }
    if (resourceName) {
      resourceName.textContent = `All ${SERVICE_LIST_LABELS[target.list.serviceType]}`;
    }
    if (resourceProject) {
      resourceProject.textContent = target.list.projectId;
    }
    regionRow?.classList.add("hidden");
    if (billingLink) {
      billingLink.href = `https://console.cloud.google.com/billing?project=${encodeURIComponent(target.list.projectId)}`;
    }
    return;
  }
  if (serviceBadge) {
    serviceBadge.textContent = "Project overview";
  }
  if (resourceName) {
    resourceName.textContent = "All services this month";
  }
  if (resourceProject) {
    resourceProject.textContent = target.project.projectId;
  }
  regionRow?.classList.add("hidden");
  if (billingLink) {
    billingLink.href = `https://console.cloud.google.com/billing?project=${encodeURIComponent(target.project.projectId)}`;
  }
}
function showNotice(doc, message, showSettingsButton, showChecklist) {
  const noticeSection = doc.getElementById("notice-section");
  const noticeMessage = doc.getElementById("notice-message");
  const settingsBtn = doc.getElementById("open-settings-btn");
  const checklist = doc.getElementById("setup-checklist");
  doc.getElementById("cost-section")?.classList.add("hidden");
  doc.getElementById("list-section")?.classList.add("hidden");
  doc.getElementById("executive-summary-card")?.classList.add("hidden");
  doc.getElementById("card-actions")?.classList.add("hidden");
  doc.getElementById("precision-badge")?.classList.add("hidden");
  noticeSection?.classList.remove("hidden");
  if (noticeMessage) {
    noticeMessage.textContent = message;
  }
  settingsBtn?.classList.toggle("hidden", !showSettingsButton);
  checklist?.classList.toggle("hidden", !showChecklist);
}
function formatCreditValue(amount, currency) {
  if (Math.abs(amount) < 5e-3) {
    return formatMoney(0, currency);
  }
  const absFormatted = formatMoney(Math.abs(amount), currency);
  return amount < 0 ? `-${absFormatted}` : absFormatted;
}
function renderWaterfall(doc, prefix, values) {
  const savingsBadge = doc.getElementById(`${prefix}-savings-badge`);
  if (savingsBadge) {
    if (values.totalSavings > 5e-3) {
      const pctText = values.savingsPercent !== null ? ` (${Math.round(values.savingsPercent)}%)` : "";
      savingsBadge.textContent = `Saved ${formatMoney(values.totalSavings, values.currency)}${pctText}`;
      savingsBadge.classList.remove("hidden");
    } else {
      savingsBadge.classList.add("hidden");
    }
  }
  const listEl = doc.getElementById(`${prefix}-list-price`);
  if (listEl) {
    listEl.textContent = formatMoney(values.listPrice, values.currency);
  }
  const contractRow = doc.getElementById(`${prefix}-contract-row`);
  const contractEl = doc.getElementById(`${prefix}-contract-discount`);
  if (values.contractDiscount > 5e-3) {
    if (contractEl) {
      contractEl.textContent = `-${formatMoney(values.contractDiscount, values.currency)}`;
    }
    contractRow?.classList.remove("hidden");
  } else {
    contractRow?.classList.add("hidden");
  }
  const beforeEl = doc.getElementById(`${prefix}-before-discounts`);
  if (beforeEl) {
    beforeEl.textContent = formatMoney(values.beforeDiscounts, values.currency);
  }
  const cudEl = doc.getElementById(`${prefix}-cud-credits`);
  if (cudEl) {
    cudEl.textContent = formatCreditValue(values.cudCredits, values.currency);
  }
  const otherRow = doc.getElementById(`${prefix}-other-credits-row`);
  const otherEl = doc.getElementById(`${prefix}-other-credits`);
  if (Math.abs(values.otherCredits) > 5e-3) {
    if (otherEl) {
      otherEl.textContent = formatCreditValue(
        values.otherCredits,
        values.currency
      );
    }
    otherRow?.classList.remove("hidden");
  } else {
    otherRow?.classList.add("hidden");
  }
}
function renderInsights(container, insights, doc) {
  if (!container) {
    return;
  }
  container.replaceChildren();
  if (insights.length === 0) {
    container.classList.add("hidden");
    return;
  }
  for (const insight of insights) {
    const li = doc.createElement("li");
    li.className = `insight-item ${insight.severity}`;
    const title = doc.createElement("div");
    title.className = "insight-title";
    title.textContent = insight.title;
    const detail = doc.createElement("div");
    detail.className = "insight-detail";
    detail.textContent = insight.detail;
    li.appendChild(title);
    li.appendChild(detail);
    if (insight.action) {
      const actionEl = doc.createElement("div");
      actionEl.className = "insight-action";
      actionEl.textContent = `Next: ${insight.action}`;
      li.appendChild(actionEl);
    }
    container.appendChild(li);
  }
  container.classList.remove("hidden");
}
function renderExecutiveSummary(payload, doc) {
  const card = doc.getElementById("executive-summary-card");
  if (!payload) {
    card?.classList.add("hidden");
    return;
  }
  const badge = doc.getElementById("summary-source-badge");
  const text = doc.getElementById("executive-summary-text");
  const note = doc.getElementById("executive-summary-note");
  if (badge) {
    badge.textContent = payload.source === "gemini" ? "Gemini AI" : "Standard Summary";
  }
  if (text) {
    text.textContent = payload.text;
  }
  if (note) {
    if (payload.note) {
      note.textContent = payload.note;
      note.classList.remove("hidden");
    } else {
      note.classList.add("hidden");
    }
  }
  card?.classList.remove("hidden");
}
function renderSidePanel(state = { status: "unsupported" }, doc = document) {
  const emptyState = doc.getElementById("empty-state");
  const statusElement = doc.getElementById("status-message");
  const resourceCard = doc.getElementById("resource-card");
  if (state.status === "unsupported") {
    if (statusElement) {
      statusElement.textContent = EMPTY_STATE_MESSAGE;
    }
    emptyState?.classList.remove("hidden");
    resourceCard?.classList.add("hidden");
    lastSummaryText = "";
    lastBreakdownItems = [];
    return;
  }
  emptyState?.classList.add("hidden");
  resourceCard?.classList.remove("hidden");
  const identity = state.status === "loaded" ? { kind: "resource", resource: state.resource } : state.status === "loaded_list" ? { kind: "service-list", list: state.list } : state.status === "loaded_project" ? { kind: "project-home", project: state.project } : state.target;
  renderIdentityHeader(identity, doc);
  if (state.status === "not_signed_in") {
    showNotice(
      doc,
      "Sign in with Google in Settings to see costs.",
      true,
      true
    );
    return;
  }
  if (state.status === "missing_settings") {
    showNotice(
      doc,
      "Connect your BigQuery billing export in Settings to see costs.",
      true,
      true
    );
    return;
  }
  if (state.status === "no_data") {
    showNotice(
      doc,
      "No billing data found yet for this page in your summary table.",
      false,
      false
    );
    return;
  }
  if (state.status === "error") {
    showNotice(doc, state.message, true, false);
    return;
  }
  doc.getElementById("notice-section")?.classList.add("hidden");
  doc.getElementById("card-actions")?.classList.remove("hidden");
  renderExecutiveSummary(state.executiveSummary, doc);
  if (state.status === "loaded_list" || state.status === "loaded_project") {
    const { breakdown } = state;
    doc.getElementById("cost-section")?.classList.add("hidden");
    doc.getElementById("list-section")?.classList.remove("hidden");
    doc.getElementById("export-csv-btn")?.classList.remove("hidden");
    lastBreakdownItems = breakdown.items;
    lastCsvFilename = state.status === "loaded_project" ? `kanakku-${state.project.projectId}-services.csv` : `kanakku-${state.list.projectId}-${state.list.serviceType}.csv`;
    const precisionBadge2 = doc.getElementById("precision-badge");
    if (precisionBadge2) {
      precisionBadge2.textContent = state.status === "loaded_project" ? `${breakdown.items.length} services` : `${breakdown.items.length} resources`;
      precisionBadge2.classList.remove("hidden");
    }
    const totalAfterEl = doc.getElementById("list-after-credits");
    if (totalAfterEl) {
      totalAfterEl.textContent = formatMoney(
        breakdown.totalAfterCredits,
        breakdown.currency
      );
    }
    renderWaterfall(doc, "list", {
      listPrice: breakdown.listPrice,
      contractDiscount: breakdown.contractDiscount,
      beforeDiscounts: breakdown.totalBeforeDiscounts,
      cudCredits: breakdown.cudCredits,
      otherCredits: breakdown.otherCredits,
      totalSavings: breakdown.totalSavings,
      savingsPercent: breakdown.savingsPercent,
      currency: breakdown.currency
    });
    const insights = state.status === "loaded_project" ? evaluateProjectInsights(breakdown, state.monthlyAlertThreshold) : evaluateListInsights(
      breakdown,
      state.list,
      state.monthlyAlertThreshold
    );
    renderInsights(doc.getElementById("list-insights-list"), insights, doc);
    renderBudgetBar(
      doc,
      "list",
      breakdown.totalAfterCredits,
      state.monthlyAlertThreshold,
      breakdown.currency
    );
    const breakdownList = doc.getElementById("breakdown-list");
    if (breakdownList) {
      breakdownList.replaceChildren();
      for (const item of breakdown.items) {
        const li = doc.createElement("li");
        li.className = "breakdown-row";
        const nameSpan = doc.createElement("span");
        nameSpan.className = "breakdown-name";
        nameSpan.textContent = item.region ? `${item.resourceName} \xB7 ${item.region}` : item.resourceName;
        const costSpan = doc.createElement("span");
        costSpan.className = "breakdown-cost";
        costSpan.textContent = formatMoney(
          item.costAfterCredits,
          item.currency
        );
        li.appendChild(nameSpan);
        li.appendChild(costSpan);
        breakdownList.appendChild(li);
      }
    }
    const listFreshnessEl = doc.getElementById("list-freshness-label");
    const freshness2 = formatFreshness(breakdown.latestUsageTime);
    if (listFreshnessEl) {
      listFreshnessEl.textContent = breakdown.fromCache ? `${freshness2} (cached)` : freshness2;
    }
    const heading = state.status === "loaded_project" ? `Project overview (${state.project.projectId})` : `${SERVICE_LIST_LABELS[state.list.serviceType]} (${state.list.projectId})`;
    lastSummaryText = [
      heading,
      `Final price this month: ${formatMoney(breakdown.totalAfterCredits, breakdown.currency)}`,
      `List price: ${formatMoney(breakdown.listPrice, breakdown.currency)}`,
      `CUD credits: ${formatCreditValue(breakdown.cudCredits, breakdown.currency)}`,
      state.executiveSummary.text,
      freshness2
    ].join("\n");
    return;
  }
  const { summary } = state;
  doc.getElementById("list-section")?.classList.add("hidden");
  doc.getElementById("cost-section")?.classList.remove("hidden");
  doc.getElementById("export-csv-btn")?.classList.add("hidden");
  lastBreakdownItems = [];
  const precisionBadge = doc.getElementById("precision-badge");
  if (precisionBadge) {
    precisionBadge.textContent = summary.precision;
    precisionBadge.classList.remove("hidden");
  }
  const afterEl = doc.getElementById("cost-after-credits");
  if (afterEl) {
    afterEl.textContent = formatMoney(
      summary.thisMonthAfterCredits,
      summary.currency
    );
  }
  renderWaterfall(doc, "cost", {
    listPrice: summary.thisMonthListPrice,
    contractDiscount: summary.thisMonthContractDiscount,
    beforeDiscounts: summary.thisMonthBeforeDiscounts,
    cudCredits: summary.thisMonthCudCredits,
    otherCredits: summary.thisMonthOtherCredits,
    totalSavings: summary.totalSavings,
    savingsPercent: summary.savingsPercent,
    currency: summary.currency
  });
  const estimateRow = doc.getElementById("cost-estimate-row");
  const estimateEl = doc.getElementById("cost-estimate");
  const projected = estimateMonthEndCost(summary);
  if (projected !== null) {
    if (estimateEl) {
      estimateEl.textContent = formatMoney(projected, summary.currency);
    }
    estimateRow?.classList.remove("hidden");
  } else {
    estimateRow?.classList.add("hidden");
  }
  const burnRow = doc.getElementById("cost-burn-row");
  const burnEl = doc.getElementById("cost-burn-rate");
  const burnRate = estimateBurnRate(summary);
  if (burnRate !== null) {
    if (burnEl) {
      const suffix = burnRate.beforeCreditsOnly ? " before credits" : "";
      burnEl.textContent = `~${formatMoney(burnRate.daily, summary.currency)}/day \xB7 ~${formatMoney(burnRate.hourly, summary.currency)}/hr${suffix}`;
    }
    burnRow?.classList.remove("hidden");
  } else {
    burnRow?.classList.add("hidden");
  }
  renderBudgetBar(
    doc,
    "cost",
    summary.thisMonthAfterCredits,
    state.monthlyAlertThreshold,
    summary.currency
  );
  const changeEl = doc.getElementById("cost-percent-change");
  if (changeEl) {
    changeEl.textContent = formatPercentChange(summary.percentChange);
  }
  renderInsights(
    doc.getElementById("insights-list"),
    evaluateCostInsights(summary, state.resource, state.monthlyAlertThreshold),
    doc
  );
  const chartEl = doc.getElementById("daily-chart");
  if (chartEl) {
    renderDailyChart(chartEl, summary.dailySeries, summary.currency);
  }
  const freshness = formatFreshness(summary.latestUsageTime);
  const freshnessEl = doc.getElementById("freshness-label");
  if (freshnessEl) {
    freshnessEl.textContent = summary.fromCache ? `${freshness} (cached)` : freshness;
  }
  lastSummaryText = [
    `${state.resource.resourceName} (${SERVICE_LABELS[state.resource.serviceType]}, ${state.resource.projectId})`,
    `Final price this month: ${formatMoney(summary.thisMonthAfterCredits, summary.currency)}`,
    `List price: ${formatMoney(summary.thisMonthListPrice, summary.currency)}`,
    `CUD credits: ${formatCreditValue(summary.thisMonthCudCredits, summary.currency)}`,
    state.executiveSummary.text,
    `${summary.precision} | ${freshness}`
  ].join("\n");
}
function setLoading(isLoading) {
  document.getElementById("loading-banner")?.classList.toggle("hidden", !isLoading);
}
function requestCostState(forceRefresh = false) {
  if (typeof chrome === "undefined" || !chrome.runtime) {
    return;
  }
  setLoading(true);
  const request = {
    type: "GET_SIDE_PANEL_STATE",
    forceRefresh
  };
  void chrome.runtime.sendMessage(request).then((state) => {
    if (state) {
      renderSidePanel(state);
    }
  }).catch(() => renderSidePanel({ status: "unsupported" })).finally(() => setLoading(false));
}
function initSidePanel() {
  renderSidePanel({ status: "unsupported" });
  document.getElementById("open-settings-btn")?.addEventListener("click", () => {
    void chrome.runtime?.sendMessage({
      type: "OPEN_OPTIONS"
    });
  });
  document.getElementById("refresh-btn")?.addEventListener("click", () => {
    requestCostState(true);
  });
  document.getElementById("list-refresh-btn")?.addEventListener("click", () => {
    requestCostState(true);
  });
  const copyBtn = document.getElementById("copy-summary-btn");
  copyBtn?.addEventListener("click", () => {
    if (!lastSummaryText || !navigator.clipboard) {
      return;
    }
    void navigator.clipboard.writeText(lastSummaryText).then(() => {
      copyBtn.textContent = "Copied!";
      setTimeout(() => {
        copyBtn.textContent = "Copy summary";
      }, 1500);
    });
  });
  document.getElementById("export-csv-btn")?.addEventListener("click", () => {
    if (lastBreakdownItems.length === 0) {
      return;
    }
    const csv = buildBreakdownCsv(lastBreakdownItems);
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = lastCsvFilename;
    link.click();
    URL.revokeObjectURL(url);
  });
  if (typeof chrome === "undefined" || !chrome.runtime) {
    return;
  }
  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === "COST_STATE_CHANGED") {
      setLoading(false);
      renderSidePanel(message.state);
    }
  });
  requestCostState(false);
}
if (typeof document !== "undefined") {
  initSidePanel();
}
export {
  renderSidePanel
};
